# Retail Sales Analysis (2024)

A beginner-friendly but *realistic* data analyst portfolio project: cleaning a
messy retail sales dataset and turning it into business insights.

This is the kind of project that shows a hiring manager you can handle real
data — not a spreadsheet that's already clean and ready to plot.

## What this project demonstrates

- **Data cleaning:** handling missing values, duplicate rows, inconsistent
  text formatting (casing/whitespace), and invalid values (negative
  quantities) — with justified imputation choices, not just `dropna()`.
- **Exploratory Data Analysis (EDA):** grouping, aggregation, and summary
  statistics with pandas.
- **Data visualization:** bar charts, line charts (time trend), and a
  scatter plot with `matplotlib` / `seaborn`.
- **Business thinking:** translating charts into plain-English insights and
  recommendations — the part that actually matters to employers.

## Project structure

```
sales-analysis-project/
├── data/
│   └── sales_data.csv          # synthetic, intentionally messy dataset (1,200+ orders)
├── notebook/
│   └── sales_analysis.ipynb    # main analysis notebook (already executed, with outputs)
├── images/                     # charts exported as PNG
├── generate_data.py            # script that generated the synthetic dataset
├── build_notebook.py           # script that programmatically builds the notebook
├── requirements.txt
└── README.md
```

## Dataset

`data/sales_data.csv` contains 1,200+ synthetic retail orders across 2024 with:

| Column | Description |
|---|---|
| OrderID | Unique order identifier |
| OrderDate | Date of the order |
| Category | Product category (Electronics, Apparel, Home & Kitchen, Sports, Stationery) |
| Product | Specific product name |
| Region | North / South / East / West |
| CustomerSegment | Consumer / Small Business / Corporate |
| Quantity | Units sold |
| UnitPrice | Price per unit ($) |
| Sales | Quantity × UnitPrice (with seasonal adjustment) |
| Profit | Profit on the order ($) |

The data was generated with realistic messiness on purpose (missing values,
duplicates, inconsistent casing, a few negative quantities) to mirror what
you'd actually receive at a job.

## How to run it

```bash
pip install -r requirements.txt
jupyter notebook notebook/sales_analysis.ipynb
```

Or regenerate everything from scratch:

```bash
python generate_data.py          # creates data/sales_data.csv
jupyter nbconvert --to notebook --execute --inplace notebook/sales_analysis.ipynb
```

## Key questions answered

1. Which categories and regions drive the most revenue and profit?
2. How do sales trend across the year — is there seasonality?
3. Which customer segment is most valuable?
4. Does order quantity relate to profit, or is margin more important?

Open the notebook to see the full analysis, charts, and the "Key Insights"
and "Recommendations" sections at the end.

## Next steps to extend this project

- Swap in a real public dataset (e.g. Kaggle's "Superstore Sales" dataset) once
  comfortable with the workflow.
- Add a simple forecasting model (e.g. linear trend or `Prophet`) for next
  quarter's sales.
- Build a small dashboard version in Streamlit or Power BI/Tableau using the
  same cleaned dataset.
- Add unit tests for the cleaning logic if turning this into a repeatable
  pipeline.
