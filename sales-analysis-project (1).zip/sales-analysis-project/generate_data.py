"""
generate_data.py
-----------------
Creates a synthetic, intentionally messy retail sales dataset so the
analysis notebook has real cleaning work to do (nulls, duplicates,
inconsistent casing, stray whitespace) — just like a real dataset a
fresher analyst would receive at work.
"""

import numpy as np
import pandas as pd

np.random.seed(42)

N = 1200

categories = {
    "Electronics": ["Wireless Mouse", "Bluetooth Speaker", "USB-C Cable", "Laptop Stand", "Webcam"],
    "Apparel": ["Cotton T-Shirt", "Denim Jeans", "Hoodie", "Running Shoes", "Baseball Cap"],
    "Home & Kitchen": ["Non-stick Pan", "Coffee Mug", "LED Lamp", "Storage Box", "Cutting Board"],
    "Sports": ["Yoga Mat", "Dumbbell Set", "Water Bottle", "Resistance Band", "Skipping Rope"],
    "Stationery": ["Notebook", "Gel Pen Pack", "Sticky Notes", "Desk Organizer", "Whiteboard Marker"],
}

regions = ["North", "South", "East", "West"]
segments = ["Consumer", "Small Business", "Corporate"]

rows = []
order_id = 1000
dates = pd.date_range("2024-01-01", "2024-12-31", freq="D")

for _ in range(N):
    category = np.random.choice(list(categories.keys()))
    product = np.random.choice(categories[category])
    region = np.random.choice(regions)
    segment = np.random.choice(segments, p=[0.55, 0.30, 0.15])
    date = np.random.choice(dates)
    quantity = np.random.randint(1, 15)

    base_prices = {
        "Electronics": (15, 90), "Apparel": (8, 45), "Home & Kitchen": (5, 60),
        "Sports": (6, 55), "Stationery": (1, 12),
    }
    lo, hi = base_prices[category]
    unit_price = round(np.random.uniform(lo, hi), 2)

    # seasonal boost in Nov/Dec
    month = pd.Timestamp(date).month
    seasonal_mult = 1.4 if month in (11, 12) else 1.0
    sales = round(quantity * unit_price * seasonal_mult, 2)

    margin = np.random.uniform(0.05, 0.35)
    profit = round(sales * margin, 2)

    rows.append([
        f"ORD{order_id}", date, category, product, region, segment,
        quantity, unit_price, sales, profit
    ])
    order_id += 1

df = pd.DataFrame(rows, columns=[
    "OrderID", "OrderDate", "Category", "Product", "Region", "CustomerSegment",
    "Quantity", "UnitPrice", "Sales", "Profit"
])

# ---- Inject realistic messiness ----

# 1. Missing values
for col in ["Quantity", "UnitPrice", "Region", "CustomerSegment"]:
    idx = np.random.choice(df.index, size=int(0.03 * N), replace=False)
    df.loc[idx, col] = np.nan

# 2. Inconsistent casing / whitespace in categorical text
df.loc[df.sample(frac=0.1, random_state=1).index, "Region"] = df["Region"].str.lower()
df.loc[df.sample(frac=0.1, random_state=2).index, "CustomerSegment"] = (
    " " + df["CustomerSegment"].astype(str) + "  "
)

# 3. Duplicate rows
dupes = df.sample(frac=0.02, random_state=3)
df = pd.concat([df, dupes], ignore_index=True)

# 4. A few negative quantities (data entry errors / returns miscoded)
err_idx = np.random.choice(df.index, size=5, replace=False)
df.loc[err_idx, "Quantity"] = -abs(df.loc[err_idx, "Quantity"].fillna(1))

# 5. Recompute Sales as NaN wherever Quantity or UnitPrice is NaN (real-world dependency)
df.loc[df["Quantity"].isna() | df["UnitPrice"].isna(), "Sales"] = np.nan

df = df.sample(frac=1, random_state=7).reset_index(drop=True)  # shuffle

df.to_csv("data/sales_data.csv", index=False)
print(f"Generated data/sales_data.csv with {len(df)} rows.")
