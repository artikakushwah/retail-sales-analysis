import nbformat as nbf

nb = nbf.v4.new_notebook()
cells = []

def md(text):
    cells.append(nbf.v4.new_markdown_cell(text))

def code(text):
    cells.append(nbf.v4.new_code_cell(text))

# ---------------- Title ----------------
md("""# Retail Sales Analysis — 2024

**Goal:** Clean a messy retail sales dataset, explore it, and answer business
questions a manager would actually ask:

1. Which product categories and regions drive the most revenue and profit?
2. How do sales trend across the year, and is there seasonality?
3. Which customer segment is most valuable?
4. What data-quality issues exist, and how were they handled?

**Tools:** pandas, numpy, matplotlib, seaborn
""")

# ---------------- Setup ----------------
code("""import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

sns.set_theme(style="whitegrid")
plt.rcParams["figure.dpi"] = 110

df = pd.read_csv("../data/sales_data.csv", parse_dates=["OrderDate"])
df.shape
""")

md("## 1. First look at the data")
code("""df.head()""")
code("""df.info()""")
code("""df.describe(include="all").T""")

# ---------------- Data quality check ----------------
md("""## 2. Data quality check

Before trusting any numbers, check for the usual suspects: missing values,
duplicate rows, and inconsistent text formatting.
""")
code("""print("Missing values per column:")
print(df.isna().sum())
print("\\nFully duplicated rows:", df.duplicated().sum())
print("\\nUnique Region values (raw):", df["Region"].unique())
print("Unique CustomerSegment values (raw):", df["CustomerSegment"].unique())
""")

md("""**Findings:**
- Some rows are missing `Quantity`, `UnitPrice`, `Region`, or `CustomerSegment`.
- `Sales` is missing wherever `Quantity` or `UnitPrice` is missing (expected, since Sales = Quantity × UnitPrice).
- `Region` has inconsistent casing (`"north"` vs `"North"`).
- `CustomerSegment` has stray leading/trailing whitespace.
- There are duplicate rows (likely double-logged orders).
- A few `Quantity` values are negative, which isn't valid for a sale.

## 3. Cleaning the data
""")

code("""clean = df.copy()

# Standardize text columns: strip whitespace, fix casing
clean["Region"] = clean["Region"].str.strip().str.title()
clean["CustomerSegment"] = clean["CustomerSegment"].str.strip()

# Drop exact duplicate rows
before = len(clean)
clean = clean.drop_duplicates()
print(f"Dropped {before - len(clean)} duplicate rows")

# Fix invalid negative quantities -> treat as data entry error, take absolute value
neg_mask = clean["Quantity"] < 0
print(f"Fixing {neg_mask.sum()} negative Quantity values")
clean.loc[neg_mask, "Quantity"] = clean.loc[neg_mask, "Quantity"].abs()

# Impute missing UnitPrice with the median price for that Product
clean["UnitPrice"] = clean.groupby("Product")["UnitPrice"].transform(
    lambda x: x.fillna(x.median())
)

# Impute missing Quantity with the overall median quantity
clean["Quantity"] = clean["Quantity"].fillna(clean["Quantity"].median())

# Recompute Sales wherever it was missing, now that inputs are filled
recompute_mask = clean["Sales"].isna()
clean.loc[recompute_mask, "Sales"] = clean.loc[recompute_mask, "Quantity"] * clean.loc[recompute_mask, "UnitPrice"]

# Drop rows still missing a category we can't safely impute (Region/Segment)
clean = clean.dropna(subset=["Region", "CustomerSegment"])

print("\\nRemaining missing values:")
print(clean.isna().sum())
print("\\nFinal shape:", clean.shape)
""")

md("Cleaning summary: standardized text fields, removed duplicates, fixed invalid negative quantities, "
   "imputed missing prices/quantities sensibly, and recomputed dependent `Sales` values rather than dropping "
   "usable rows outright.")

# ---------------- EDA ----------------
md("""## 4. Revenue and profit by category""")
code("""cat_summary = (
    clean.groupby("Category")[["Sales", "Profit"]]
    .sum()
    .sort_values("Sales", ascending=False)
)
cat_summary["ProfitMargin%"] = (cat_summary["Profit"] / cat_summary["Sales"] * 100).round(1)
cat_summary
""")

code("""fig, ax = plt.subplots(figsize=(8, 5))
cat_summary["Sales"].sort_values().plot(kind="barh", ax=ax, color="#4C72B0")
ax.set_xlabel("Total Sales ($)")
ax.set_title("Total Sales by Category")
plt.tight_layout()
plt.savefig("../images/sales_by_category.png")
plt.show()
""")

md("## 5. Sales by region and customer segment")
code("""fig, axes = plt.subplots(1, 2, figsize=(12, 5))

region_summary = clean.groupby("Region")["Sales"].sum().sort_values(ascending=False)
region_summary.plot(kind="bar", ax=axes[0], color="#55A868")
axes[0].set_title("Total Sales by Region")
axes[0].set_ylabel("Total Sales ($)")
axes[0].tick_params(axis="x", rotation=0)

segment_summary = clean.groupby("CustomerSegment")["Sales"].sum().sort_values(ascending=False)
segment_summary.plot(kind="bar", ax=axes[1], color="#C44E52")
axes[1].set_title("Total Sales by Customer Segment")
axes[1].tick_params(axis="x", rotation=0)

plt.tight_layout()
plt.savefig("../images/sales_by_region_segment.png")
plt.show()
""")

md("## 6. Monthly sales trend (seasonality check)")
code("""clean["Month"] = clean["OrderDate"].dt.to_period("M").astype(str)
monthly = clean.groupby("Month")["Sales"].sum()

fig, ax = plt.subplots(figsize=(10, 5))
monthly.plot(kind="line", marker="o", ax=ax, color="#8172B2")
ax.set_ylabel("Total Sales ($)")
ax.set_title("Monthly Sales Trend — 2024")
ax.tick_params(axis="x", rotation=45)
plt.tight_layout()
plt.savefig("../images/monthly_trend.png")
plt.show()
""")

md("## 7. Top 10 best-selling products")
code("""top_products = (
    clean.groupby("Product")["Sales"]
    .sum()
    .sort_values(ascending=False)
    .head(10)
)

fig, ax = plt.subplots(figsize=(8, 6))
top_products.sort_values().plot(kind="barh", ax=ax, color="#DA8BC3")
ax.set_xlabel("Total Sales ($)")
ax.set_title("Top 10 Products by Sales")
plt.tight_layout()
plt.savefig("../images/top_products.png")
plt.show()
""")

md("## 8. Does order quantity relate to profit? (correlation check)")
code("""fig, ax = plt.subplots(figsize=(7, 5))
sns.scatterplot(data=clean, x="Quantity", y="Profit", hue="Category", alpha=0.6, ax=ax)
ax.set_title("Quantity vs Profit by Category")
plt.tight_layout()
plt.savefig("../images/quantity_vs_profit.png")
plt.show()

print("Correlation between Quantity and Profit:", round(clean["Quantity"].corr(clean["Profit"]), 3))
""")

# ---------------- Insights ----------------
md("""## 9. Key insights

*(Numbers below are computed live from the cells above — re-run the notebook to refresh them.)*
""")
code("""top_category = cat_summary["Sales"].idxmax()
top_region = region_summary.idxmax()
top_segment = segment_summary.idxmax()
best_month = monthly.idxmax()
best_product = top_products.idxmax()
qty_profit_corr = round(clean["Quantity"].corr(clean["Profit"]), 2)

print(f"- Top-performing category by revenue: {top_category}")
print(f"- Top-performing region: {top_region}")
print(f"- Most valuable customer segment: {top_segment}")
print(f"- Peak sales month: {best_month} (seasonal lift around Nov/Dec)")
print(f"- Best-selling individual product: {best_product}")
print(f"- Correlation between order quantity and profit: {qty_profit_corr} (weak/no linear relationship — profit is driven more by margin than volume)")
""")

md("""## 10. Recommendations

- Double down on marketing spend for the top category and region ahead of the Nov/Dec seasonal peak.
- Investigate why quantity doesn't strongly predict profit — pricing/margin strategy likely matters more than pushing volume.
- The Corporate segment (if smaller in count but high in value) may warrant a dedicated account-management approach rather than blanket promotions.
- Fix upstream data entry issues (negative quantities, inconsistent region naming) at the source system to reduce future cleaning overhead.
""")

nb["cells"] = cells
with open("notebook/sales_analysis.ipynb", "w") as f:
    nbf.write(nb, f)

print("Notebook built.")
